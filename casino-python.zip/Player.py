class Player:
    def __int__(self):
        self.id: 0
        self.name: ""
        self.gain: 0

    def getId(self):
        return self.id

    def setId(self, id):
        self.id = id

    def getName(self):
        return self.name

    def setName(self, name):
        self.name = name

    def getGain(self):
        return self.gain

    def setGain(self, gain):
        self.gain = gain